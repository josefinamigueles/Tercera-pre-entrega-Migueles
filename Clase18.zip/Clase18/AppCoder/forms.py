from django import forms



class Curso_formulario(forms.Form):

    nombre_curso = forms.CharField(max_length=30)
    camada = forms.IntegerField()