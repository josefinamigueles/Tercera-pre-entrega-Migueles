from django.shortcuts import render
from AppCoder.models import Curso
from django.http import HttpResponse
from django.template import loader 
from AppCoder.forms import Curso_formulario
# Create your views here.

def inicio(request):
    return render( request , "padre.html")

def alta_curso(request, nombre):
    curso = Curso(nombre=nombre , camada=234512)
    curso.save()
    texto = f"Se guardo en la base de datos el curso: {curso.nombre} {curso.camada}"
    return HttpResponse(texto)

def alta_alumnos(request):
    alumno = alumno(nombre=nombre_alumno , apellido=apellido_alumno)
    alumno.save()
    texto = f"Se guardo en la base de datos el alumno: {alumno.nombre_alumno} {alumno.apellido_alumno}"
    return HttpResponse(texto)

def ver_cursos(request):
    cursos = Curso.objects.all()
    dicc = {"cursos": cursos}
    plantilla = loader.get_template("cursos.html")
    documento = plantilla.render(dicc)
    return HttpResponse(documento)

def alumnos(request):
    return render(request , "alumnos.html")

def profesores(request):
    return render (request , "profesores.html")

def curso_formulario(request):

    if request.method == "POST":

        mi_formulario = Curso_formulario( request.POST )

        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data

            curso = Curso( nombre=request.POST ["nombre"] , camada = request.POST["camada"] )
            curso.save()
            return render(request , "formulario.html")

    return render(request , "formulario.html")

def alumnos_formulario(request):
    if request.method == "POST":

        mi_formularioalm = alumnos_formulario( request.POST )

        if mi_formularioalm.is_valid():
            datos = mi_formularioalm.cleaned_data

            alumno = alumno( nombre=request.POST ["nombre"] , apellido = request.POST["apellido"] )
            alumno.save()
            return render(request , "formulario_alumnos.html")

    return render(request , "formulario.html")







def buscar_curso(request):
    return render(request, "buscar_curso.html")

def buscar(request):

    if request.GET["nombre_curso"]:
        nombre = request.GET["nombre_curso"]
        cursos = Curso.objects.filter(nombre__icontains= nombre)
        return render( request, "resultado_busqueda.html", {"cursos": cursos})
    else:
        return HttpResponse("Ingrese el nombre del curso")